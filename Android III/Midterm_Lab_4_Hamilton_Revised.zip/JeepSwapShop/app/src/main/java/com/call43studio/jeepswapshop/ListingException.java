//ListingException Class
//This class ties all the ListingException messages when a user is applying data in the app.

package com.call43studio.jeepswapshop;

public class ListingException extends Exception {

    public ListingException(String message)
    {
        super(message);
    }

}
